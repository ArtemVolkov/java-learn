create function "overlaps"(timestamp without time zone, interval, timestamp without time zone, timestamp without time zone) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select ($1, ($1 + $2)) overlaps ($3, $4)
$$;
