create function integer_pl_date(integer, date) returns date
IMMUTABLE
LANGUAGE SQL
AS $$
select $2 + $1
$$;
